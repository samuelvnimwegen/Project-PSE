//
// Created by Samuel on 05/05/2023.
//

#include "Metrostation.h"

Metrostation::Metrostation() {
    setTypeString("Metrostation");
}


