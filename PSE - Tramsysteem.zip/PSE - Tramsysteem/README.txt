PSE - Project van Samuel van Nimwegen en Moaad Kharicha

De XML testfiles zitten apart in het mapje "test XML files". Deze zitten ook nog in "cmake-build-debug" en dit is ook waarde de output .txt files normaal zouden moeten komen. TramSysteem is de algemene class die alles regelt, de andere classes worden gebruikt om informatie bij te houden voor deze class. De tests zitten in "tests.cpp" en in "main.cpp" zitten een aantal voorbeeld lijnen code die laten zien hoe het systeem werkt.

