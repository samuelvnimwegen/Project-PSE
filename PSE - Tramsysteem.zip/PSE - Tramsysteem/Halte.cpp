//
// Created by Samuel on 05/05/2023.
//

#include "Halte.h"

Halte::Halte() {
    setTypeString("Halte");
}
