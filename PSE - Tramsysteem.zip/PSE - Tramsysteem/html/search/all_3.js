var searchData=
[
  ['getaantaldefecten_0',['getAantalDefecten',['../class_p_c_c.html#a850319ad22f40e2002a57d2939a8ce32',1,'PCC']]],
  ['getbeginstation_1',['getBeginStation',['../class_tram.html#abe386592de6a7930df75ea184b945403',1,'Tram']]],
  ['getlijnnr_2',['getLijnNr',['../class_tram.html#ad2404fa7837b41287feab05f6a1b52bf',1,'Tram']]],
  ['getnaam_3',['getNaam',['../class_station.html#a5cb0b0a752b33d922c541ef7531b16f4',1,'Station']]],
  ['getoutput_4',['getOutput',['../class_tram_systeem.html#ab6e4a5ca76c0912f763b75ecbde0746d',1,'TramSysteem']]],
  ['getreparatiekost_5',['getReparatieKost',['../class_p_c_c.html#ae1ed0e8030a2ac7dd786a36377f6b4fd',1,'PCC']]],
  ['getreparatietijd_6',['getReparatieTijd',['../class_p_c_c.html#a7b39039b183b18e2400c3ee6ca64fabb',1,'PCC']]],
  ['getsnelheid_7',['getSnelheid',['../class_tram.html#a46f2d45724ea921ee2b952cbf060f983',1,'Tram']]],
  ['getspoornr_8',['getSpoorNr',['../class_station.html#aa87a627e10424e0ac074adf1f84fbf24',1,'Station']]],
  ['getstations_9',['getStations',['../class_lijn.html#a1246ec9bc27b8cf9b6c00ab099bcbbcf',1,'Lijn::getStations()'],['../class_tram_systeem.html#a2adf00773d90bc54837efd3a81c7c1ad',1,'TramSysteem::getStations()']]],
  ['gettotalekosten_10',['getTotaleKosten',['../class_p_c_c.html#a65595e510411ecbc56ce832b9c4aac6c',1,'PCC']]],
  ['gettrams_11',['getTrams',['../class_lijn.html#aa8a03f3e2319e078b10793989f440ba3',1,'Lijn::getTrams()'],['../class_tram_systeem.html#ab442331060a0f422daab82c40724b99b',1,'TramSysteem::getTrams()']]],
  ['gettypestring_12',['getTypeString',['../class_station.html#a878c449015cd8b044c6534fbbca7e144',1,'Station::getTypeString()'],['../class_tram.html#abf5c835f83a225688ab5bd097d1cf341',1,'Tram::getTypeString() const']]],
  ['getvoertuignummer_13',['getVoertuigNummer',['../class_tram.html#a6e9f78befa2850add25925559ed98bc1',1,'Tram']]],
  ['getvolgende_14',['getVolgende',['../class_station.html#a330c297adddcbfd5d8871075291e9512',1,'Station']]],
  ['getvorige_15',['getVorige',['../class_station.html#a69c0539e899ff540c38eb434a69bfa9e',1,'Station']]]
];
