var searchData=
[
  ['albatros_0',['Albatros',['../class_albatros.html',1,'']]]
];
