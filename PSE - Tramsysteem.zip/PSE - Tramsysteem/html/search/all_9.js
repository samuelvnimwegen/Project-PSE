var searchData=
[
  ['pcc_0',['PCC',['../class_p_c_c.html',1,'PCC'],['../class_p_c_c.html#a942d36135d139dcecffe2bc438847491',1,'PCC::PCC()']]],
  ['properlyinitialized_1',['properlyInitialized',['../class_tram_systeem.html#a43083ac8c53627e5788cde80bca1218f',1,'TramSysteem']]]
];
