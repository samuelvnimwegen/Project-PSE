var searchData=
[
  ['isconsistent_0',['isConsistent',['../class_tram_systeem.html#acaddd46c3f038b1d159c56e7ca314ffb',1,'TramSysteem']]],
  ['iskapot_1',['isKapot',['../class_p_c_c.html#a4607e4699940705e95c7854db83804fe',1,'PCC']]]
];
