var searchData=
[
  ['addstation_0',['addStation',['../class_lijn.html#ac60ff590af0e5216531caebda4ec139c',1,'Lijn']]],
  ['addtram_1',['addTram',['../class_lijn.html#a4872e7e26ddcdd67a7516a414c3b5c13',1,'Lijn::addTram()'],['../class_tram_systeem.html#a87999d42d5854639395cf47ae1d4f366',1,'TramSysteem::addTram()']]],
  ['addtramaanstation_2',['addTramAanStation',['../class_station.html#ae0636f13902691a2fb538c61524f266d',1,'Station']]],
  ['advanced_5fsummary_3',['advanced_summary',['../class_tram_systeem_out.html#a9414d2a335e4cc1ed5310dee360c2688',1,'TramSysteemOut']]]
];
